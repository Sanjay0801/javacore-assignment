interface example {
    void read();
    void write();
    void contribute();
}
  
// Abstract class Student implementing from GFG interface
abstract class Student implements example {
  
    // Overriding the methods
    @Override public void read()
    {
        System.out.println(
            "student is reading");
    }
    @Override public void writing()
    {
        System.out.println(
            "student is writing");
    }
}
  
// Extend the GEEK class by Student abstract class
class Abc extends Student {
    @Override public void contribute()
    {
        System.out.println(
            "Now let's help others by contributing");
    }
}
  
// Driver code
public class Main {
    public static void main(String[] args)
    {
        // New GEEK object is created
        Abc stu = new Abc();
  
        // Calls to the multiple functions
        stu.read();
        stu.write();
        stu.contribute();
    }
}